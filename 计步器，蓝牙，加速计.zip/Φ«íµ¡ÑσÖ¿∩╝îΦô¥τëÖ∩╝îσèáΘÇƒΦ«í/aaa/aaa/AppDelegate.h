//
//  AppDelegate.h
//  aaa
//
//  Created by bean on 16/3/31.
//  Copyright © 2016年 com.xile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


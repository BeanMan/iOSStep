//
//  ViewController.m
//  aaa
//
//  Created by bean on 16/3/31.
//  Copyright © 2016年 com.xile. All rights reserved.
//

#import "ViewController.h"

#import <CoreMotion/CoreMotion.h>
@interface ViewController ()
{
    //计步器对象
    CMPedometer * step;
    
    //系统蓝牙设备管理对象，可以把他理解为主设备，通过他，可以去扫描和链接外设
    //    CBCentralManager * blueManager;
    UILabel * lll;
}
//@property(nonatomic,strong)CMMotionManager * manager;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(100, 100, 100, 100);
    btn.backgroundColor = [UIColor redColor];
    [btn addTarget:self action:@selector(click) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    
    lll = [[UILabel alloc]initWithFrame:CGRectMake(0, 200, 200, 20)];
    lll.backgroundColor = [UIColor blackColor];
    lll.textColor = [UIColor redColor];
    [self.view addSubview:lll];
    // 第一步，判断设备是否支持
    if (![CMPedometer isStepCountingAvailable])
    {
        NSLog(@"不可用");
        return;
    }
    step = [[CMPedometer alloc]init];
    //开始计步
    [step startPedometerUpdatesFromDate:[NSDate date] withHandler:^(CMPedometerData * _Nullable pedometerData, NSError * _Nullable error) {
        NSLog(@"%@",pedometerData.numberOfSteps);
        lll.text =[NSString stringWithFormat:@"%@",pedometerData.numberOfSteps];
    }];
    
    
    
    /*
     第二步，可以查询过去某段时间内走过的步数
     */
    [step queryPedometerDataFromDate:[NSDate dateWithTimeInterval:-24*60*60 sinceDate:[NSDate date]] toDate:[NSDate date] withHandler:^(CMPedometerData * _Nullable pedometerData, NSError * _Nullable error) {
        if (error) {
            NSLog(@"查询错误 %@", error);
            return ;
        }
        NSLog(@"+++++++++%@", pedometerData.numberOfSteps);
        dispatch_async(dispatch_get_main_queue(), ^{
            
            lll.text = [NSString stringWithFormat:@"%@", pedometerData.numberOfSteps];
        });
    }];
    
    
//    // 第三步，更新从某个时间开始的步数变化
//    
//    [step startPedometerUpdatesFromDate:[NSDate dateWithTimeInterval:-24*60*60 sinceDate:[NSDate date]] withHandler:^(CMPedometerData * _Nullable pedometerData, NSError * _Nullable error) {
//        if (error) {
//            NSLog(@"更新错误 %@", error);
//            return ;
//        }
//        NSLog(@"________%@", pedometerData.numberOfSteps);
//        dispatch_async(dispatch_get_main_queue(), ^{
//            lll.text = [NSString stringWithFormat:@"%@", pedometerData.numberOfSteps];
//        });
//    }];
    
    
    
}

-(void)click
{
    
//    [step stopPedometerUpdates];
    
    // 第三步，更新从某个时间开始的步数变化
    
    [step startPedometerUpdatesFromDate:[NSDate dateWithTimeInterval:-24*60*60 sinceDate:[NSDate date]] withHandler:^(CMPedometerData * _Nullable pedometerData, NSError * _Nullable error) {
        if (error)
        {
            NSLog(@"更新错误 %@", error);
            return ;
        }
        NSLog(@"________%@", pedometerData.numberOfSteps);
        dispatch_async(dispatch_get_main_queue(), ^{
            lll.text = [NSString stringWithFormat:@"%@", pedometerData.numberOfSteps];
        });
    }];

    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

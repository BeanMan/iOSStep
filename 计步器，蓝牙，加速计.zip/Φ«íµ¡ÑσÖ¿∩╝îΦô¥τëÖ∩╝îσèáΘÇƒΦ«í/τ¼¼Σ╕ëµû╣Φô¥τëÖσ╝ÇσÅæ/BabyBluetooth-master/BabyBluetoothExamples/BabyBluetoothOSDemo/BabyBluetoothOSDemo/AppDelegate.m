//
//  AppDelegate.m
//  BabyBluetoothOSDemo
//
//  Created by liuyanwei on 15/9/6.
//  Copyright (c) 2015年 liuyanwei. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}

@end

//
//  AppDelegate.m
//  BabyTestStub
//
//  Created by ZTELiuyw on 16/3/14.
//  Copyright © 2016年 liuyanwei. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}

@end
